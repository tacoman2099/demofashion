import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface ClosetStatsProps {
  stats: {
    all: number;
    tops: number;
    bottoms: number;
    shoes: number;
    outerwear: number;
    accessories: number;
  };
}

const ClosetStats: React.FC<ClosetStatsProps> = ({ stats }) => {
  return (
    <Card className="bg-muted/50">
      <CardContent className="p-4">
        <div className="flex justify-between">
          <div className="text-center">
            <p className="text-lg font-bold">{stats.all}</p>
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{stats.tops}</p>
            <p className="text-xs text-muted-foreground">Tops</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{stats.bottoms}</p>
            <p className="text-xs text-muted-foreground">Bottoms</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{stats.shoes}</p>
            <p className="text-xs text-muted-foreground">Shoes</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">{stats.outerwear}</p>
            <p className="text-xs text-muted-foreground">Outer</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClosetStats;