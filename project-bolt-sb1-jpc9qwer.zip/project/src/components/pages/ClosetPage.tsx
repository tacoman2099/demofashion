import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { TabsContent, Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { mockClosetItems } from '@/data/mockData';
import ClosetHeader from '../features/closet/ClosetHeader';
import ClosetGrid from '../features/closet/ClosetGrid';
import ClosetStats from '../features/closet/ClosetStats';

type CategoryType = 'all' | 'tops' | 'bottoms' | 'shoes' | 'outerwear' | 'accessories';

const ClosetPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('all');
  
  const filteredItems = activeCategory === 'all' 
    ? mockClosetItems 
    : mockClosetItems.filter(item => item.category.toLowerCase() === activeCategory);

  const categoryStats = {
    all: mockClosetItems.length,
    tops: mockClosetItems.filter(item => item.category.toLowerCase() === 'tops').length,
    bottoms: mockClosetItems.filter(item => item.category.toLowerCase() === 'bottoms').length,
    shoes: mockClosetItems.filter(item => item.category.toLowerCase() === 'shoes').length,
    outerwear: mockClosetItems.filter(item => item.category.toLowerCase() === 'outerwear').length,
    accessories: mockClosetItems.filter(item => item.category.toLowerCase() === 'accessories').length
  };

  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      <ClosetHeader />
      
      <ClosetStats stats={categoryStats} />
      
      <Tabs defaultValue="all" onValueChange={(value) => setActiveCategory(value as CategoryType)}>
        <TabsList className="grid grid-cols-6 h-11 mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="tops">Tops</TabsTrigger>
          <TabsTrigger value="bottoms">Bottoms</TabsTrigger>
          <TabsTrigger value="shoes">Shoes</TabsTrigger>
          <TabsTrigger value="outerwear">Outer</TabsTrigger>
          <TabsTrigger value="accessories">Acc</TabsTrigger>
        </TabsList>
        
        {/* We don't need separate TabsContent elements as we're filtering based on the active category */}
        <TabsContent value="all" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
        <TabsContent value="tops" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
        <TabsContent value="bottoms" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
        <TabsContent value="shoes" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
        <TabsContent value="outerwear" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
        <TabsContent value="accessories" className="m-0">
          <ClosetGrid items={filteredItems} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ClosetPage;