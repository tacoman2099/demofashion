import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Repeat, Bookmark, MoreHorizontal } from 'lucide-react';
import PostActions from '../features/feed/PostActions';
import { mockPosts } from '@/data/mockData';
import FeedHeader from '../features/feed/FeedHeader';

const FeedPage: React.FC = () => {
  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      <FeedHeader />
      
      <div className="space-y-6">
        {mockPosts.map((post) => (
          <Card key={post.id} className="overflow-hidden border-none shadow-md rounded-xl">
            <CardHeader className="p-4 pb-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8 border border-border">
                    <AvatarImage src={post.user.avatar} alt={post.user.name} />
                    <AvatarFallback>{post.user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-sm">{post.user.name}</div>
                    <div className="text-xs text-muted-foreground">{post.timestamp}</div>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0 mt-4">
              <img
                src={post.imageUrl}
                alt="Fashion post"
                className="w-full object-cover"
                style={{ maxHeight: '500px' }}
              />
            </CardContent>
            <CardFooter className="p-4 flex flex-col items-start gap-2">
              <PostActions post={post} />
              <div>
                <p className="text-sm font-medium">{post.caption}</p>
                <p className="text-xs text-muted-foreground mt-1">{post.tags.map(tag => `#${tag}`).join(' ')}</p>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default FeedPage;