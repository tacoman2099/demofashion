import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import TrendingOutfits from '../features/discover/TrendingOutfits';
import { mockTrendingUsers } from '@/data/mockData';

const DiscoverPage: React.FC = () => {
  return (
    <div className="max-w-md mx-auto p-4 space-y-6">
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Discover</h1>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search styles, users, brands..." 
            className="pl-9 h-10"
          />
        </div>
      </div>
      
      <Tabs defaultValue="trending">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="popular">Popular</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
          <TabsTrigger value="brands">Brands</TabsTrigger>
        </TabsList>
      </Tabs>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Popular Creators</h2>
        <ScrollArea className="w-full whitespace-nowrap pb-2">
          <div className="flex gap-4">
            {mockTrendingUsers.map((user) => (
              <div key={user.id} className="flex flex-col items-center space-y-2 w-16">
                <Avatar className="h-16 w-16 border-2 border-primary">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <span className="text-xs text-center truncate w-full">{user.name}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
      
      <TrendingOutfits />
    </div>
  );
};

export default DiscoverPage;