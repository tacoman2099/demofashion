import React, { useState } from 'react';
import NavigationBar from './NavigationBar';
import FeedPage from '../pages/FeedPage';
import ClosetPage from '../pages/ClosetPage';
import DiscoverPage from '../pages/DiscoverPage';
import ProfilePage from '../pages/ProfilePage';
import { Toaster } from '@/components/ui/toaster';
import AddItemModal from '../features/closet/AddItemModal';

type AppPage = 'feed' | 'discover' | 'add' | 'closet' | 'profile';

const AppLayout: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<AppPage>('feed');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const handleNavigation = (page: AppPage) => {
    if (page === 'add') {
      setIsAddModalOpen(true);
    } else {
      setCurrentPage(page);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <div className="flex-1 overflow-y-auto pb-20">
        {currentPage === 'feed' && <FeedPage />}
        {currentPage === 'discover' && <DiscoverPage />}
        {currentPage === 'closet' && <ClosetPage />}
        {currentPage === 'profile' && <ProfilePage />}
      </div>
      
      <NavigationBar currentPage={currentPage} onNavigate={handleNavigation} />
      <AddItemModal open={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />
      <Toaster />
    </div>
  );
};

export default AppLayout;