export interface ClosetItemType {
  id: string;
  name: string;
  brand: string;
  category: string;
  color: string;
  season: string;
  imageUrl: string;
}